import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.neighbors import KNeighborsRegressor
from sklearn import neighbors
from sklearn.model_selection import GridSearchCV



df = pd.read_csv("Wine data.csv")
print(df)


for col in df.columns:
  if df[col].isnull().sum() > 0:                 
    df[col] = df[col].fillna(df[col].mean())
    
df = df.drop('total sulfur dioxide', axis=1)

features = df.drop(['quality'], axis=1)
target = df['quality']
x_train, x_test, y_train, y_test = train_test_split(features, target, test_size = 0.25)


norm = MinMaxScaler()
x_train = norm.fit_transform(x_train)
x_test = norm.transform(x_test)

params = {'n_neighbors': [2,3,4,5,6,7,8,9,10,11,12,13,14,15]}
knn_reg = neighbors.KNeighborsRegressor()
model_reg = GridSearchCV(knn_reg, params, cv = 5)

model_reg.fit(x_train, y_train)
predictions = model_reg.predict(x_test)
predictions = [round(x) for x in predictions] 
print(predictions)
data = pd.DataFrame({"Actual Close" : y_test, "Predicted Close Value" : predictions})
print(data)